const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("SupplyChain", function () {
    let SupplyChain;
    let supplyChain;
    let owner;
    let addr1;
    let addr2;

    beforeEach(async function () {
        SupplyChain = await ethers.getContractFactory("SupplyChain");
        [owner, addr1, addr2, ...addrs] = await ethers.getSigners();
        supplyChain = await SupplyChain.deploy();
        await supplyChain.deployed();
    });

    describe("User Registration and Login", function () {
        it("should register a user successfully", async function () {
            await supplyChain.registerUser("Alice", addr1.address, 0, ethers.utils.formatBytes32String("password123"));
            const user = await supplyChain.users(addr1.address);
            expect(user.name).to.equal("Alice");
        });

        it("should fail to register an already registered user", async function () {
            await supplyChain.registerUser("Alice", addr1.address, 0, ethers.utils.formatBytes32String("password123"));
            await expect(supplyChain.registerUser("Alice", addr1.address, 0, ethers.utils.formatBytes32String("password123")))
                .to.be.revertedWith("User already registered");
        });

        it("should login successfully with correct password", async function () {
            await supplyChain.registerUser("Alice", addr1.address, 0, ethers.utils.formatBytes32String("password123"));
            const loginSuccess = await supplyChain.login(addr1.address, ethers.utils.formatBytes32String("password123"));
            expect(loginSuccess).to.be.true;
        });

        it("should fail to login with incorrect password", async function () {
            await supplyChain.registerUser("Alice", addr1.address, 0, ethers.utils.formatBytes32String("password123"));
            const loginSuccess = await supplyChain.login(addr1.address, ethers.utils.formatBytes32String("wrongpassword"));
            expect(loginSuccess).to.be.false;
        });
    });

    describe("Product Management", function () {
        beforeEach(async function () {
            await supplyChain.registerUser("Producer", owner.address, 0, ethers.utils.formatBytes32String("password123"));
        });

        it("should add a product successfully", async function () {
            await supplyChain.addProduct("Product 1", 100);
            const product = await supplyChain.products(1);
            expect(product.name).to.equal("Product 1");
            expect(product.price).to.equal(100);
        });

        it("should fail to add a product if not a producer", async function () {
            await supplyChain.registerUser("Alice", addr1.address, 1, ethers.utils.formatBytes32String("password123"));
            await expect(supplyChain.connect(addr1).addProduct("Product 1", 100))
                .to.be.revertedWith("Invalid user type");
        });
    });

    describe("Transactions", function () {
        beforeEach(async function () {
            await supplyChain.registerUser("Producer", owner.address, 0, ethers.utils.formatBytes32String("password123"));
            await supplyChain.addProduct("Product 1", 100);
        });

        it("should add a transaction successfully", async function () {
            await supplyChain.registerUser("Distributor", addr1.address, 1, ethers.utils.formatBytes32String("password123"));
            await supplyChain.connect(addr1).addTransaction(1, 100, "Buy", { value: 100 });
            const product = await supplyChain.products(1);
            expect(product.owner).to.equal(addr1.address);
        });

        it("should fail to add a transaction for a non-existent product", async function () {
            await supplyChain.registerUser("Distributor", addr1.address, 1, ethers.utils.formatBytes32String("password123"));
            await expect(supplyChain.connect(addr1).addTransaction(999, 100, "Buy", { value: 100 }))
                .to.be.revertedWith("Product does not exist");
        });
    });

    describe("Fetching Data", function () {
        beforeEach(async function () {
            await supplyChain.registerUser("Producer", owner.address, 0, ethers.utils.formatBytes32String("password123"));
            await supplyChain.addProduct("Product 1", 100);
        });

        it("should get all products successfully", async function () {
            const products = await supplyChain.getAllProducts();
            expect(products.length).to.equal(1);
            expect(products[0].name).to.equal("Product 1");
        });

        it("should get product transactions successfully", async function () {
            await supplyChain.registerUser("Distributor", addr1.address, 1, ethers.utils.formatBytes32String("password123"));
            await supplyChain.connect(addr1).addTransaction(1, 100, "Buy", { value: 100 });
            const transactions = await supplyChain.getProductTransactions(1);
            expect(transactions.length).to.equal(1);
            expect(transactions[0].action).to.equal("Buy");
        });

        it("should fail to get transactions for a non-existent product", async function () {
            await expect(supplyChain.getProductTransactions(999))
                .to.be.revertedWith("Product does not exist");
        });
    });
});
