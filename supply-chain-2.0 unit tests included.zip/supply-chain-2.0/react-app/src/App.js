import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomeScreen from "./UserViews/HomeScreen";
import Signup from "./UserViews/Signup";
import Marketplace from "./UserViews/Marketplace";
import Orders from "./UserViews/Orders";
import ProductTransaction from "./UserViews/ProductTransaction";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomeScreen/>}/>
        <Route path="/sign-up" element={<Signup/>}/>
        <Route path="/marketplace" element={<Marketplace/>}/>
        <Route path="/my-orders" element={<Orders/>}/>
        <Route path="/product-transaction/:index" element={<ProductTransaction/>}/>

      </Routes>
    </Router>
   
  );
}
export default App;
