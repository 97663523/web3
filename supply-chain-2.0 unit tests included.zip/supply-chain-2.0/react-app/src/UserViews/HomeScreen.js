import React, { useState } from "react";
import { Link } from "react-router-dom";
import { HiEye, HiEyeOff } from "react-icons/hi";
import { useNavigate } from "react-router-dom";
import { login } from "../blockchain";

const HomeScreen = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [userAddress, setUserAddress] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();


  const addressHandler = (e) => {

    setUserAddress(e.target.value)

  }

  const passwordHandler = (e) => {

    setPassword(e.target.value)

  }

  const loginUser = () => {

    try {
      login(userAddress, password);
      localStorage.setItem('address', userAddress);
      navigate('/marketplace')


    } catch (error) {
      alert('Incorrect Details!')

    }

  }



  return (
    <>
      <div className="grid h-screen w-screen justify-items-center bg-gradient-to-r  from-slate-500 to-orange-300 ">
        <div className="bg-slate-200 h-[10vh] w-screen flex items-center pl-3 ">
          <h1 className="font-bold text-2xl">
            Products Supply Chain Transactions Logs
          </h1>
        </div>
        <div className="max-w-md w-full h-[450px] bg-gradient-to-r from-blue-800 to-purple-600 rounded-xl shadow-2xl overflow-hidden p-8 space-y-8 mb-14">
          <h2 className="text-center text-4xl font-extrabold text-white">
            Welcome
          </h2>
          <p className="text-center text-gray-200">Sign in to your account</p>
          <form method="POST" action="#" className="space-y-6">
            <div className="relative">
              <input
                placeholder="john@example.com"
                className="peer h-10 w-full border-b-2 border-gray-300 text-white bg-transparent placeholder-transparent focus:outline-none focus:border-purple-500"
                required=""
                id="email"
                name="address"
                type="text"
                onChange={addressHandler}
              />
              <label
                className="absolute left-0 -top-3.5 text-gray-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-purple-500 peer-focus:text-sm"
                htmlFor="email"
              >
                Consumer address
              </label>
            </div>
            <div className="relative">
              <input
                placeholder="Password"
                className="peer h-10 w-full border-b-2 border-gray-300 text-white bg-transparent placeholder-transparent focus:outline-none focus:border-purple-500"
                required=""
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                onChange={passwordHandler}
              />

              <label
                className="absolute flex justify-between w-full left-0 -top-3.5 text-gray-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-400 peer-placeholder-shown:top-2 peer-focus:-top-3.5 peer-focus:text-purple-500 peer-focus:text-sm"
                htmlFor="password"
              >
                Password
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <HiEyeOff /> : <HiEye />}
                </button>
              </label>
            </div>

            <button
              className="w-full py-2 px-4 bg-purple-500 hover:bg-purple-700 rounded-md shadow-lg text-white font-semibold transition duration-200"
              onClick={loginUser}
            >
              Sign In
            </button>
          </form>
          <div className="text-center text-gray-300">
            Don't have an account?
            <Link
              className="text-white hover:underline font-bold pl-1"
              to="/sign-up"
            >
              Sign up
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default HomeScreen;
