const { Web3 } = require('web3');


// Load contract ABI
const contractABI = require("./SupplyChain.json").abi;
// Contract address
const contractAddress = '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512';

// Initialize Web3 instance
const web3 = new Web3('http://127.0.0.1:8545/');

// Initialize contract instance
const supplyChainContract = new web3.eth.Contract(contractABI, contractAddress);

// User registration
export async function registerUser(name, userAddress, userType, password) {
    try {
        const accounts = await web3.eth.getAccounts();
        const password1 = web3.utils.asciiToHex(password).padEnd(66, '0');
        const result = await supplyChainContract.methods.registerUser(name, userAddress, userType, password1).send({ from: userAddress, gas: 300000 });
        console.log('User registered:', result);
    } catch (error) {
        console.error('Error registering user:', error);
    }
}

// User login
export async function login(userAddress, password) {
    try {
        const password1 = web3.utils.asciiToHex(password).padEnd(66, '0');

        const result = await supplyChainContract.methods.login(userAddress, password1).call();
        console.log('User login status:', result);
    } catch (error) {
        console.error('Error logging in:', error);
    }
}

// Add product
async function addProduct(productName, userAddress) {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await supplyChainContract.methods.addProduct(productName).send({ from: userAddress, gas: 300000 });
        console.log('Product added:', result);
    } catch (error) {
        console.error('Error adding product:', error);
    }
}

// Add transaction
export async function addTransaction(productId, price, action, userAddress) {
    try {
        const result = await supplyChainContract.methods.addTransaction(productId, price, action).send({ from: userAddress, gas: 300000, value: price });
        console.log('Transaction added:', result);
        return result;
    } catch (error) {
        console.error('Error adding transaction:', error);
    }
}

// Get product transactions
export async function getProductTransactions(productId) {
    try {
        const result = await supplyChainContract.methods.getProductTransactions(productId).call();
        console.log('Product transactions:', result);
        return result;
    } catch (error) {
        console.error('Error getting product transactions:', error);
    }
}
export async function getAllProducts() {
    try {
        let result = await supplyChainContract.methods.getAllProducts().call();
        console.log('All products:', result);
        result = result?.filter((tx) => {
            return tx.transactionIds.length == 2;
        });
        return result;
    } catch (error) {
        console.error('Error getting all products:', error);
    }
}

