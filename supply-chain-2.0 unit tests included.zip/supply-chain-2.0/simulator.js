const { Web3 } = require('web3');


// Load contract ABI
const contractABI = require("./artifacts/contracts/supplychain.sol/SupplyChain.json").abi;
// Contract address
const contractAddress = '0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512';

// Initialize Web3 instance
const web3 = new Web3('http://127.0.0.1:8545/');

// Initialize contract instance
const supplyChainContract = new web3.eth.Contract(contractABI, contractAddress);

// User registration
async function registerUser(name, userAddress, userType, password) {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await supplyChainContract.methods.registerUser(name, userAddress, userType, password).send({ from: userAddress, gas: 300000 });
        console.log('User registered:', result);
    } catch (error) {
        console.error('Error registering user:', error);
    }
}

// User login
async function login(userAddress, password) {
    try {
        const result = await supplyChainContract.methods.login(userAddress, password).call();
        console.log('User login status:', result);
    } catch (error) {
        console.error('Error logging in:', error);
    }
}

// Add product
async function addProduct(productName, productPrice, userAddress) {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await supplyChainContract.methods.addProduct(productName, productPrice).send({ from: userAddress, gas: 300000 });
        console.log('Product added:', result);
    } catch (error) {
        console.error('Error adding product:', error);
    }
}

// Add transaction
async function addTransaction(productId, price, action = "Transaction Succesfull", userAddress) {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await supplyChainContract.methods.addTransaction(productId, price, action).send({ from: userAddress, gas: 300000, value: price });
        console.log('Transaction added:', result);
    } catch (error) {
        console.error('Error adding transaction:', error);
    }
}

// Get product transactions
async function getProductTransactions(productId) {
    try {
        const result = await supplyChainContract.methods.getProductTransactions(productId).call();
        console.log('Product transactions:', result);
    } catch (error) {
        console.error('Error getting product transactions:', error);
    }
}

async function getAllProducts() {
    try {
        const result = await supplyChainContract.methods.getAllProducts().call();
        console.log('All products:', result);
    } catch (error) {
        console.error('Error getting all products:', error);
    }
}

async function testSupplyChain() {

    const password1 = web3.utils.asciiToHex("password1").padEnd(66, '0');
    const password2 = web3.utils.asciiToHex("password2").padEnd(66, '0');
    const password3 = web3.utils.asciiToHex("password3").padEnd(66, '0');
    const password4 = web3.utils.asciiToHex("password4").padEnd(66, '0');

    // // Register users
    // await registerUser("Producer1", "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", 0, password1);
    // await registerUser("Distributor1", "0x70997970C51812dc3A010C7d01b50e0d17dc79C8", 1, password2);
    // await registerUser("Retailer1", "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", 2, password3);
    // await registerUser("Consumer1", "0x90F79bf6EB2c4f870365E785982E1f101E93b906", 3, password4);

    // Log in users
    // await login("0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266", password1);
    // await login("0x70997970C51812dc3A010C7d01b50e0d17dc79C8", password2);
    // await login("0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC", password3);
    // await login("0x90F79bf6EB2c4f870365E785982E1f101E93b906", password4);

    // // Add products
    // await addProduct("Product1", 100, '0xFABB0ac9d68B0B445fB7357272Ff202C5651694a');
    // await addProduct("Product new", 100, '0xFABB0ac9d68B0B445fB7357272Ff202C5651694a');

    // // Add transactions
    // await addTransaction(1, 100, "Producer1 -> Distributor1", '0x90F79bf6EB2c4f870365E785982E1f101E93b906');
    // await addTransaction(1, 150, "Distributor1 -> Retailer1", '0x15d34AAf54267DB7D7c367839AAf71A00a2C6A65');
    // await addTransaction(1, 200, "Retailer1 -> Consumer1", '0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc');

    // await addTransaction(1, 120, "Producer1 -> Distributor1", '0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc');
    // await addTransaction(1, 170, "Distributor1 -> Retailer1", '0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc');
    // await addTransaction(1, 220, "Retailer1 -> Consumer1", '0x9965507D1a55bcC2695C58ba16FB37d819B0A4dc');

    // // Get product transactions
    // await getProductTransactions(1);
    // await getProductTransactions(2);
}

testSupplyChain();
